from osqp.interface import OSQP
from osqp.interface import solve
from osqp._osqp import constant
